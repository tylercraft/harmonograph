const CONFIG = {
  // Set to true to use stub data — no APIs, no auth required
  stub: false,
};
